<?php

require_once('config.php');
require_once('database.php');
$cookie_name = "user" ;
$login = false;
$test = new data_base();

if(isset($_GET['auth_id']))
{
    $check = $_GET['auth_id'];
   	$sql = "UPDATE ".DB_NAME.".personal_info SET auth_status = 'TRUE' WHERE auth_key = '".$check."'";
    $result = mysql_query($sql);
    $sql= "SELECT cookie FROM ".DB_NAME.".personal_info  WHERE auth_key = '".$check."'";
    $result = mysql_query($sql);

    if($result != null )
    {
		$row = mysql_fetch_assoc($result);
		$cookie_name = "user";
		$cookie_value = $row["cookie"];
		$sql = "CREATE TABLE IF NOT EXISTS ".$cookie_value."_portfolio (stock_ticker varchar(20) NOT NULL, quantity int(10) NOT NULL DEFAULT '0', cost_price double NOT NULL , stock_name varchar(100) NOT NULL ,
		CONSTRAINT 
    	FOREIGN KEY (stock_ticker)
    	REFERENCES prediction(stock_ticker)
   		ON DELETE CASCADE
   		)";
		echo $sql;
		$result = mysql_query($sql);
		$sql = "CREATE TABLE IF NOT EXISTS ".$cookie_value."_watchlist ( stock_ticker varchar(20) NOT NULL , hit_value int(11) NOT NULL , stock_name varchar(100) NOT NULL ,
		CONSTRAINT 
    	FOREIGN KEY (stock_ticker)
    	REFERENCES prediction(stock_ticker)
   		ON DELETE CASCADE
   		)";
		echo $sql;
		$result = mysql_query($sql);
		setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
		header("Location: index.php");
	}
}

if(!isset($_COOKIE[$cookie_name])) 
{

}
else 
{  

      $login = true;
      $table = 'personal_info';
    
      $sql= "SELECT * FROM ".DB_NAME.".".$table." WHERE cookie = '".$_COOKIE[$cookie_name]."'";
      $result = mysql_query($sql);
	  $row = mysql_fetch_assoc($result);


	  $string  ='';	 
	  $string2 ='';

	  if($row['gender'] == "MALE" || $row['gender'] == "male")
	  {
		  $string  = '<td> <label><input type="radio" name="gender" checked="checked" value="MALE">Male</label> </td>'	; 
		  $string2 ='<td> <label><input type="radio" name="gender" value ="FEMALE">Female</label> </td>';
	  }
	  else
	  {
	  	  $string  = '<td> <label><input type="radio" name="gender"  value="MALE">Male</label> </td>'	 ;
		  $string2 ='<td> <label><input type="radio" name="gender" checked="checked" value ="FEMALE">Female</label> </td>' ;
	  }
}

?>





<!DOCTYPE html>
<html lang="en">
<head>
  <title>Stock Falcon</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="main2.css">
  <script type="text/javascript" src="js/validate.js" ></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
  <script src="sweetalert-master/lib/sweet-alert.min.js"></script> 
  <script type="text/javascript" src="js/jquery-1.11.2.js"></script>
  <link rel="stylesheet" type="text/css" href="sweetalert-master/lib/sweet-alert.css">
  <script>
function refresh()
{
    $(document).ready(function(){
        setInterval(function() {
          $("#content2").each(function()
		    {
			    var images = $(this).find("div");
			    $("#latestData").load("getLatestData.php");
			});
        }, 2000);
    });

}
 
function loadImage() {
    alert("Image is loaded");
}
</script>

</head>
<header >
	
		<img id ="head" src="images/StockFalconLogo-other.jpg" alt="Mountain View" style="width:152px;height:147px">
		<br>
		<br>
		<br>
		
		<ul class="nav navbar-nav navbar-right">
			 <font face="verdana"> 
			 	<font color="green">     
			 	 <a href="#" onClick="">Site Map</a>
			 	 <br>
			  	<a href="#" onClick="">Contact Us</a>
			  	<br>
			  	<a href="#" onClick="">Disclaimer</a>
			  </font>
			</font>

		</ul>
		
		<h1 id="head1">Stock Falcon</h1>
</header>

<body onload="refresh()">



<div>
	<nav class="navbar navbar-default">
			 <div class="container-fluid">
			    <!-- Brand and toggle get grouped for better mobile display -->
			    <div class="navbar-header">
				     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				        <span class="sr-only">Toggle navigation</span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span> 
				     </button>

    			
			    
				    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				      <ul class="nav navbar-nav">
				        <li><a href="#" onClick="$('#search_box').hide(2000); $('#FAQ_box').hide(2000); $('#About_box').hide(2000); $('#home_box').show(2000)"	>Home</a></li>
				        <li><a href="#" onClick="$('#home_box').hide(2000); $('#About_box').hide(2000); $('#FAQ_box').hide(2000); $('#search_box').show(2000)"	>Search</a></li>
				       	<li><a href="#" onClick="$('#search_box').hide(2000); $('#home_box').hide(2000); $('#About_box').hide(2000); $('#FAQ_box').show(2000)"	>FAQ</a></li>
				       	<li><a href="#" onClick="$('#search_box').hide(2000); $('#FAQ_box').hide(2000); $('#home_box').hide(2000); $('#About_box').show(2000)"	>About Us</a></li>
				      </ul>
					</div>

				</div>
			
			     


			     <?php
				      if($login == false)
				      { echo '
				      <ul class="nav navbar-nav navbar-right">
				        <li class="dropdown">

				          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Login/Register<span class="caret"></span></a>
				          <ul class="dropdown-menu" role="menu">
				            <li>
				            	<button type="button" class="btn btn-default btn-sm temp_button" data-toggle="modal" data-target="#myModal_reg">Login</button>
				            </li>
				            <li>
				            	<button type="button" class="btn btn-default btn-sm temp_button" data-toggle="modal" data-target="#myModal_log">Register</button>
				            </li>
				          </ul>
				        </li>
				      </ul>


				     <div class="modal fade" id="myModal_reg" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
								      <div class="modal-header">
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								        <h4 class="modal-title" id="myModalLabel">Login</h4>
								      </div>
								      <div class="modal-body">
								        <form id="loginform" class="form-horizontal" role="form">
									        <div style="margin-bottom: 20px" id="email_append">
												<div style="margin-bottom: 5px" class="input-group" >
									            	<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
									            	<input id="login-username" type="text" class="form-control" name="username" placeholder="User Email"> 
									            </div>
									        </div>   
									         <div style="margin-bottom: 20px" id="password_append">
									            <div style="margin-bottom: 5px" class="input-group">
									              	<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
									                <input id="login-password" type="password" class="form-control" name="password" placeholder="password"></div>
									            </div> 
									         <div style="margin-top:10px" class="form-group">
									         	<div class="col-sm-12 controls">
									                <a id="btn-login" href="#" class="btn btn-success" onclick="return validate()">Login  </a>
												</div>
									         </div>
									    </form> 
									  </div>
						    	</div>
							</div>
					 </div>
					 <div class="modal fade" id="myModal_log" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
								   <div class="modal-header">
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								        <h4 class="modal-title" id="myModalLabel">Register</h4>
								    </div>
								    <div class="modal-body">
								       <form name = "sign_up" id="signupform" class="form-horizontal" role="form">      
				                        		<div class="form-group" >
				                        		
				                                    <label for="firstname" class="col-md-3 control-label">First Name</label>
				                                    <div class="col-md-9">
				                                    <div id="firstname_append">
				                                        <input type="text" class="form-control" name="firstname" placeholder="First Name">
				                                    </div>
				                                	</div>
				                                </div>
				                                <div class="form-group">
				                                    <label for="lastname" class="col-md-3 control-label">Last Name</label>
				                                    <div class="col-md-9">
				                                    <div id="lastname_append">
				                                        <input type="text" class="form-control" name="lastname" placeholder="Last Name">
				                                    </div>
				                                    </div>
				                                </div>
				                                <div class="form-group">
				                                    <label for="password" class="col-md-3 control-label">Password</label>
				                                    <div class="col-md-9">
				                                    <div id="passwd_append">
				                                        <input type="password" class="form-control" name="passwd" placeholder="Password">
				                                    </div>
				                                    </div>
				                                </div>
				                                <div class="form-group">
				                                    <label for="Retype password" class="col-md-3 control-label">Retype Password</label>
				                                    
				                                    <div class="col-md-9">
				                                    <div id="passwd1_append">
				                                        <input type="password" class="form-control" name="passwd1" placeholder="Retype Password">
				                                    </div>
				                                    </div>
				                                </div>
				                                <div class="form-group">
				                                    <label for="birthdate" class="col-md-3 control-label">Birth date</label>
				                                    <div class="col-md-9">
				                                    <div id="birthdate_append">
				                                        <input type="date" class="form-control" name="birthdate">
				                                    </div>
				                                    </div>
				                                </div>
				                                <div class="form-group">
				                                    <label for="email" class="col-md-3 control-label">Email</label>
				                                    <div class="col-md-9">
				                                    <div id="Email_append">
				                                        <input type="email" class="form-control" name="email" placeholder="xyz@domain.com">
				                                    </div>
				                                    </div>
				                                </div>
				                                    
				                                <div class="form-group">
				                                    <label for="gender" class="col-md-3 control-label">Gender</label>
							                          <div class="radio">
								                           <div class="col-md-9">
								                           <div id="gender_append">
									                           <tr>
									                           <td> <label><input type="radio" name="gender" value="MALE">Male</label> </td>
									                           <td> <label><input type="radio" name="gender" value ="FEMALE">Female</label> </td>
									                           </tr>
								                           </div>
								                           </div>
							                           </div>
				                          		</div>
												<div class="form-group">
				                                    <!-- Button -->                                        
				                                    <div class="col-md-offset-3 col-md-9">
				                                        <button id="btn-signup" type="button" onclick="return validate_registeration()" class="btn btn-info"><i class="icon-hand-right"></i> Sign Up</button>
				                                        <span style="margin-left:8px;"></span>  
				                                    </div>
				                                </div>
				                        </form>
								    </div>
								</div>
				    		</div>
				 	 </div>
	                                

				      ';
				  	}
				  	else
				  	{
				  		echo '<ul class="nav navbar-nav navbar-right">';
				      	if($row['type'] != "USER")
						  {
						  	echo '<li><a href="admin.php">Advance Settings </a></li>';
						  }
						  else
						  {
						  	 echo '<li><a href="user_profile.php">Dashboard</a></li>';
				  		  }
				    echo '<li class="dropdown">
				          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Hello '.$row['first_name'].' ! <span class="caret"></span></a>
				          <ul class="dropdown-menu" role="menu">
				            <li><button type="button" class="btn btn-default btn-sm temp_button" data-toggle="modal" data-target="#myModal1">Change Password</button></li>
				            <li><button type="button" class="btn btn-default btn-sm temp_button" data-toggle="modal" data-target="#myModal2"> Edit Profile</button></li>
				            <li><button type="button" class="btn btn-default btn-sm temp_button" data-toggle="modal" data-target="#myModal3">Help</button></li>
				            <li><button type="button" class="btn btn-default btn-sm temp_button" onclick="return logout()">Logout</button></li>
				          </ul>
				        </li>
				      </ul>
				      ';
				  	}
				?>
							
        </div> 
    </nav>
</div>





<div id = "content" >
		<div id="home_box" >
			<div id = "txt">
				Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
			</div>	
		</div>

		<div id="search_box" style="display:none; margin-bottom: 10% ">
			<div class="col-lg-9" id= "search_button"> 
    			<div class="input-group">
      				<input type="text" class="form-control" onkeyup="showHint(this.value)" placeholder="Stock Name">
     				<span class="input-group-btn">
       	 				<button class="btn btn-default" type="button">Go!</button>
     				 </span>
    			</div><!-- /input-group -->
    			<br>
  			 </div><!-- /.col-lg-6 -->
		</div>

		<div id="FAQ_box" style="display:none;">
			<div id="wrapper">
			
		
			<div id="primary">
				<h3 id="1">Here are some of the facts of Stock Markets</h3>
				<ul class="section_menu">
					<li><a class = "faq" href="#1_1">WHY WOULD I CHOOSE STOCKS IN THE FIRST PLACE?</a></li>
					<li><a class = "faq" href="#1_2">WHAT INSTRUMENTS ARE TRADED IN THE STOCK MARKETS?</a></li>
					<li><a class = "faq" href="#1_3">WHERE DO I BUY STOCKS?</a></li>
					<li><a class = "faq" href="#1_4">WHERE DO I FIND STOCK RELATED INFORMATION?</a></li>
					<li><a class = "faq" href="#1_5">WHAT ARE ADVANCES AND DECLINES?</a></li>
					<li><a class = "faq" href="#1_6">HOW CAN YOU QUALIFY THE MARKET AS BULL OR BEAR?</a></li>
					<li><a class = "faq" href="#1_7">WHAT NEXT?</a></li>
				</ul>
				<dl class="faq_1">
				  <dt id="1_1">WHY WOULD I CHOOSE STOCKS IN THE FIRST PLACE?</dt>
				    <dd>Stocks are one of the most effective tools for building wealth, as stocks are a share of ownership of a company. You thus have great potential to receive monetary benefits when you own stock shares. Owning stocks of fundamentally strong companies simply lets your money work harder for you since they appreciate in value over a period of time while also offering rich dividends on a periodic basis.</dd>
				  <dt id="1_2">WHAT INSTRUMENTS ARE TRADED IN THE STOCK MARKETS?</dt>
				    <dd>The various types of instruments traded in the stock market include shares, mutual funds, IPOs, futures and options.</dd>
				  <dt id="1_3">WHERE DO I BUY STOCKS?</dt>
				    <dd>Stock trading happens on stock exchanges. However, you cannot buy directly at the exchange. To buy stocks, you need to find a suitable broker who will understand your needs and buy stocks on your behalf. You can think of them as agents who will conduct transactions for you without actually owning any of the securities themselves. In exchange for facilitating or executing a trade, brokers will charge you a commission. You can easily buy stocks through our website. Once you are registered with us, you can trade using the Stock Falcon website, our desktop trading application and Trade facility.</dd>
				  <dt id="1_4">WHERE DO I FIND STOCK RELATED INFORMATION?</dt>
				    <dd>Some of the most accessible avenues to get stock information are the internet, business news channels and print media. You could alternatively access our website and get all the information that you wanted within a matter of seconds.</dd>
				  <dt id="1_5">WHAT ARE ADVANCES AND DECLINES?</dt>
				    <dd>Advances and declines give you an indication of how the overall market has performed. You get a good overview of the general market direction. As the name suggest 'advances' inform you how the market has progressed. In contrast, 'declines' signal if the market has not performed as per expectations. The Advance-Decline ratio is a technical analysis tool that indicates market movement. </dd>
				  <dt id="1_6">HOW CAN YOU QUALIFY THE MARKET AS BULL OR BEAR?</dt>
				    <dd>Bull and bear markets signify relatively long-term movements of significant proportion. Hence, these runs can be gauged only when the market has been moving in its current direction (by about 20% of its value) for a sustained period. One does not consider small, short-term movements that last for a few days, as they may only indicate corrections or short-lived movements.</dd>
				  <dt id="1_7">WHAT NEXT?</dt>
				    <dd>Congrats, now you know all about the trading in the equity markets, different kinds of stocks as well as the prerequisites for trading – demat and trading accounts. Now, let’s move on to the currency market. Click here.
					In case you have any more queries regarding your accounts or trading, check here.</dd>
				</dl>
				
			</div>
			
		</div>

		</div>
		<div id="About_box" style="display:none;">
			<div id = "txt">
				Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
			</div>
		</div>

</div>
<div id = "content2">
 		<div id="latestData" >
 			<?php

 				$sql_card = "SELECT * FROM stockfalcon.last WHERE id = 1";
				$result_card = mysql_query($sql_card);
				$row_card = mysql_fetch_array($result_card);
				$var = $row_card['stock_ticker'];
				$url = 'http://finance.google.com/finance/info?client=ig&q=NSE%3a'.urlencode($var);
				$varq = "";
				$output = @file_get_contents($url); 
				$vfar = substr($output,6,(strlen($output)-8));
				$obj = json_decode($vfar);
				echo "<h4>".$obj->{"t"}."</h4>";
				echo "<h4>Current ".$obj->{"l_cur"}."</h4>";
				echo "<h5>Previous Close Rs. ".$obj->{"pcls_fix"}."</h5>"."";
 			?>
 		</div>
</div>

<?php
 if($login == true)
 {
  echo '
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Change Password</h4>
      </div>
      <div class="modal-body">
       <form name="change_password" class="form-horizontal" role="form">
								                                    
			<div class="form-group">
			    <label for="password" class="col-md-3 control-label">Current Password</label>
			        
			        
			        <div class="col-md-9">
			        <div id="cpass_append">
			        	<input type="password" name ="passwd" class="form-control" >
			        </div>
			        </div>
			</div>
			 <div class="form-group">
			     <label for="new_password" class="col-md-3 control-label">New Password</label>
			        
			        <div class="col-md-9">
			        <div id="npass_append">
			        	<input type="password" name ="newpasswd" class="form-control" >
			        </div>
			        </div>
			</div>
			<div class="form-group">
			     <label for="re_password" class="col-md-3 control-label">Re-type New Password</label>
			        <div class="col-md-9">
			        <div id="rpass_append">
			            <input type="password" name ="repasswd" class="form-control" >
			        </div>
			        </div>
			</div>
								   
		</form> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onclick="return change_pass()">Save changes</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Edit Your Profile</h4>
      </div>
      <div class="modal-body">
        <form id="update_profile" class="form-horizontal" role="form">
								                                    
								                    <div class="form-group">
			                                   			<label for="firstname" class="col-md-3 control-label">First Name</label>
			                                   				<div class="col-md-9">
				                                   				<div id="cfn_append">
				                                      			<input type="text" name="firstname" value ="'.$row['first_name'].'" class="form-control" >
				                                    			</div>
			                                    			</div>
			                               			</div>
			                                		
			                                		<div class="form-group">
			                                    		<label for="lastname" class="col-md-3 control-label">Last Name</label>
			                                    			<div class="col-md-9">
				                                    			<div id="cln_append">
				                                        		<input type="text" name="lastname" value="'.$row['last_name'].'" class="form-control" >
				                                    			</div>
			                                    			</div>
			                                		</div>

			                                		<div class="form-group">
			                                    		<label for="firstname" class="col-md-3 control-label">Birth Date</label>
			                                    			<div class="col-md-9">
				                                    			<div id="cbd_append">
				                                        		<input type="date" name="birthdate" value="'.$row['birthdate'].'" class="form-control" >
				                                    			</div>
			                                    			</div>
			                                		</div>

			                                		<div class="form-group">
				                                    <label for="gender" class="col-md-3 control-label">Gender</label>
							                          <div class="radio">
								                           <div class="col-md-9">
								                           <div id="cg_append">
								                          
									                           <tr>
									                           '.$string.$string2.'
									                           </tr>
								                           
								                           </div>
								                           </div>
							                           </div>
				                          			</div>
			</form> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onclick="return edit_profile()">Save changes</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
        <form id="help" class="form-horizontal" role="form">
								                                    
			 <div class="form-group">
			    <label for="firstname" class="col-md-3 control-label">Subject</label>
			        <div class="col-md-9">
			        <div id="sub_append">
			            <textarea class="form-control" rows="1" name="subject"></textarea>
			        </div>
			        </div>
			 </div>
			                                		
			 <div class="form-group">
			     <label for="firstname" class="col-md-3 control-label">Message</label>
			    	<div class="col-md-9">
			    	<div id="msg_append">
			     		<textarea class="form-control" rows="4" name="Message"></textarea>
					</div>
					</div>
			 </div>
		</form> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" onclick="return send_message()">Send Message</button>
      </div>
    </div>
  </div>
</div>

  ';


 }


?>
</body>
</html>