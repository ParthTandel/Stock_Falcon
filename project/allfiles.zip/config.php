<?php
define('DB_NAME', 'stockfalcon');
define('DB_USER', 'project');
define('DB_PASS', 'tcejorp');
define('SITE_KEY', 'hkjfhajdjgbdjgjhgtyrtrchsjfh#*#8hkjsh&)fsckjh!@#5&*');
define('NONCE_SALT', 'GYYAGYgygshdfjhgjfsg%hsbdvhjjsbvjd$%@$%$^@%^jkhjr');
define('AUTH_SALT', 'JTYFgsjhgcsbuer(**)bnv5bdbjhkjdghuyu28478265826bhj');
?>